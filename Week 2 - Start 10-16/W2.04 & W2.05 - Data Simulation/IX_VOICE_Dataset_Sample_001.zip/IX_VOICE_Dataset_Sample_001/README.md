# IX.VOICE Dataset Sample 001 — SYNTHETIC DEMO (Draft)

## Current status
- Audio: verified WAV mono PCM16, 48 kHz, 8 source turns, ~50.07 sec after joins.
- Timing: turn inclusion boundaries computed from source clip durations and inserted pauses. They may include silence inside each clip; NOT speech-only or word timestamps.
- Transcript: PENDING verification. Speaker/role: PENDING verification.
- Emotion: NO VERIFIED LABELS. Policy/checklist: waiting for BA.
- License/model version/voice preset: document the exact generated model/version before publishing to others.

## Complete the handoff
1. Open `ground_truth/turns_to_verify.csv` in Excel/VS Code. Listen to each `audio/source_turns/XX.wav`. Fill speaker_id, speaker_role, transcript_text, verified_by; set review_status=VERIFIED for each checked row.
2. Run `python finalize_dataset.py` in this folder. It writes `ground_truth/transcript_verified.json` if all eight rows are complete.
3. Update metadata.json with verified model revision, voice presets, speaker count, license check and scenario/reference as known.
4. Hand off `audio/conversation.wav`, `ground_truth/transcript_verified.json`, `metadata.json`, and validation summary to Speech AI.
5. Keep original WAVs and this synthetic dataset separate from independent real/human evaluation data.

## Note
This is *synthetic ground truth*. Accuracy claims on real calls are NOT supported.
