import csv, json
from pathlib import Path
p=Path(__file__).resolve().parent
with (p/'ground_truth/turns_to_verify.csv').open(encoding='utf-8-sig',newline='') as f:
 rows=list(csv.DictReader(f))
if len(rows)!=8: raise SystemExit('Expected 8 turns')
for r in rows:
 if not all((r.get(k) or '').strip() for k in ('speaker_id','speaker_role','transcript_text','verified_by')):
  raise SystemExit(f"Missing fields in {r['turn_id']}: fill speaker_id, speaker_role, transcript_text, verified_by")
 if r.get('review_status','').strip()!='VERIFIED':
  raise SystemExit(f"{r['turn_id']}: set review_status to VERIFIED after listening")
 if int(r['end_ms'])<=int(r['start_ms']): raise SystemExit(f"Invalid time {r['turn_id']}")
payload={'schema_version':'0.1','scenario_id':'IXV-DS001','status':'TRANSCRIPT_SPEAKERS_VERIFIED','time_unit':'ms','timestamp_type':'clip_inclusion_boundaries','turns':[
 {'turn_id':r['turn_id'],'speaker_id':r['speaker_id'],'speaker_role':r['speaker_role'],'text':r['transcript_text'], 'start_ms':int(r['start_ms']),'end_ms':int(r['end_ms']),'verified_by':r['verified_by']}
 for r in rows]}
(p/'ground_truth/transcript_verified.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
print('Saved ground_truth/transcript_verified.json')
